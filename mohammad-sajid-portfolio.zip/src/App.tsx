/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import { 
  Github, 
  Linkedin, 
  Mail, 
  ExternalLink, 
  Code2, 
  BrainCircuit, 
  Terminal, 
  Cpu, 
  GraduationCap, 
  Send,
  Menu,
  X,
  ChevronRight,
  Database,
  Layers,
  ArrowUp,
  Check,
  Copy
} from 'lucide-react';
import { motion, AnimatePresence, useScroll, useSpring } from 'motion/react';

const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Skills', href: '#skills' },
  { name: 'Projects', href: '#projects' },
  { name: 'Resume', href: '#resume' },
  { name: 'Contact', href: '#contact' },
];

const skills = [
  { name: 'Python', icon: <Terminal className="w-6 h-6" />, level: 'Advanced' },
  { name: 'Machine Learning', icon: <BrainCircuit className="w-6 h-6" />, level: 'Learning' },
  { name: 'WordPress', icon: <Layers className="w-6 h-6" />, level: 'Advanced' },
  { name: 'Data Handling', icon: <Database className="w-6 h-6" />, level: 'Advanced' },
  { name: 'Problem Solving', icon: <Cpu className="w-6 h-6" />, level: 'Advanced' },
  { name: 'Git/GitHub', icon: <Code2 className="w-6 h-6" />, level: 'Intermediate' },
];

const projects = [
  {
    title: "AI Image Classifier",
    description: "A Python-based image classification tool using TensorFlow and Keras to identify various objects.",
    image: "https://picsum.photos/seed/ai-image/800/600",
    tags: ["Python", "TensorFlow", "ML"],
    link: "#"
  },
  {
    title: "Stock Price Predictor",
    description: "Utilizing LSTM models to predict future stock prices based on historical data patterns.",
    image: "https://picsum.photos/seed/stock/800/600",
    tags: ["Python", "Scikit-Learn", "LSTM"],
    link: "#"
  },
  {
    title: "Smart Chatbot",
    description: "A natural language processing project focused on creating a responsive and context-aware chatbot.",
    image: "https://picsum.photos/seed/chatbot/800/600",
    tags: ["NLP", "Python", "Flask"],
    link: "#"
  }
];

const resumeData = {
  education: [
    {
      degree: "Bachelor of Science (B.Sc)",
      major: "Computer Science and Engineering",
      institute: "Premier University",
      period: "2023 - 2027",
      status: "Currently Studying"
    },
    {
      degree: "Higher Secondary School Certificate",
      major: "Science",
      institute: "Bandarban Government College",
      period: "2021",
      result: "4.50 out of 5.00"
    },
    {
      degree: "Secondary School Certificate",
      major: "Science",
      institute: "Barodona Hoque Memorial High School",
      period: "2019",
      result: "3.96 out of 5.00"
    }
  ],
  experience: [
    {
      role: "Sales Executive",
      description: "Managed and confirmed customer orders across Website, WhatsApp, Facebook Messenger, Instagram, and phone. Verified product details and maintained accurate records in Google Sheets."
    },
    {
      role: "Cashier in Rangoli Shopping Mall",
      description: "Managed all cash, card, and mobile transactions with accuracy and integrity. Assisted customers in product selection and handled queries."
    },
    {
      role: "NAGAD (Trade Marketing Representative)",
      description: "Promoted Nagad services in local markets, built strong relationships with shopkeepers, and collected market feedback."
    }
  ],
  technicalSkills: [
    "MS Word, Excel, PowerPoint",
    "Google Sheets, Internet Browsing",
    "WordPress Management"
  ],
  languages: [
    { name: "English", level: "Fluency in speaking, writing & listening" },
    { name: "Bengali", level: "Excellent in speaking, writing & listening" }
  ]
};

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      setShowBackToTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const copyEmail = useCallback(() => {
    navigator.clipboard.writeText('mohammadsajid1114@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, []);

  return (
    <div className="min-h-screen bg-surface selection:bg-accent/30 selection:text-primary">
      {/* Scroll Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-accent origin-left z-[60]"
        style={{ scaleX }}
      />

      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
          <a href="#home" className="text-2xl font-display font-bold text-primary tracking-tighter">
            MS<span className="text-accent">.</span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a key={link.name} href={link.href} className="nav-link text-primary/80">
                {link.name}
              </a>
            ))}
            <a 
              href="#contact" 
              className="px-5 py-2 bg-primary text-white rounded-full text-sm font-medium hover:bg-accent transition-all duration-300"
            >
              Hire Me
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-primary" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 w-full bg-white shadow-xl md:hidden"
            >
              <div className="flex flex-col p-6 space-y-4">
                {navLinks.map((link) => (
                  <a 
                    key={link.name} 
                    href={link.href} 
                    className="text-lg font-medium text-primary"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.name}
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-1/4 -left-20 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-6 md:px-12 grid md:grid-cols-2 gap-12 items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 bg-accent/10 text-accent rounded-full text-sm font-semibold mb-6">
              Available for Collaboration
            </span>
            <h1 className="text-5xl md:text-7xl font-display font-bold text-primary leading-tight mb-6">
              Mohammad <span className="text-accent">Sajid</span>
            </h1>
            <p className="text-xl text-ink/70 mb-8 max-w-lg leading-relaxed">
              Python Learner | Future AI & Machine Learning Developer based in Chattogram. 
              Passionate about building intelligent systems and continuous learning.
            </p>
            <div className="flex flex-wrap gap-4">
              <a 
                href="#projects" 
                className="px-8 py-4 bg-primary text-white rounded-xl font-semibold hover:bg-accent transition-all shadow-lg shadow-primary/20 flex items-center gap-2"
              >
                View Projects <ChevronRight className="w-4 h-4" />
              </a>
              <a 
                href="#resume" 
                className="px-8 py-4 border-2 border-primary text-primary rounded-xl font-semibold hover:bg-primary hover:text-white transition-all flex items-center gap-2"
              >
                View Resume
              </a>
              <div className="flex items-center gap-4 px-4">
                <a href="#" className="p-2 text-primary/60 hover:text-accent transition-colors"><Github /></a>
                <a href="#" className="p-2 text-primary/60 hover:text-accent transition-colors"><Linkedin /></a>
                <a href="#" className="p-2 text-primary/60 hover:text-accent transition-colors"><Mail /></a>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl relative z-10 border-8 border-white">
              <img 
                src="https://picsum.photos/seed/sajid/800/800" 
                alt="Mohammad Sajid" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-accent rounded-2xl -z-10 animate-pulse" />
            <div className="absolute -top-6 -right-6 w-32 h-32 border-4 border-primary/10 rounded-2xl -z-10" />
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1">
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">About Me</h2>
              <div className="space-y-4 text-ink/80 text-lg leading-relaxed">
                <p>
                  I'm a 22-year-old developer from the beautiful city of Chattogram, currently on an exciting journey to master Python and Machine Learning.
                </p>
                <p>
                  My fascination with technology started early, but it was the potential of Artificial Intelligence that truly captured my imagination. I believe that AI is the most transformative technology of our time, and I'm dedicated to becoming a part of its future.
                </p>
                <p>
                  When I'm not coding, you'll find me exploring the latest tech trends, participating in coding challenges, or learning about the intersection of mathematics and machine learning.
                </p>
              </div>
              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="p-4 bg-surface rounded-xl border border-primary/5">
                  <h4 className="font-bold text-primary">Location</h4>
                  <p className="text-sm text-ink/60">Chattogram, Bangladesh</p>
                </div>
                <div className="p-4 bg-surface rounded-xl border border-primary/5">
                  <h4 className="font-bold text-primary">Age</h4>
                  <p className="text-sm text-ink/60">22 Years Old</p>
                </div>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="relative group">
                <div className="absolute inset-0 bg-accent rounded-3xl rotate-3 group-hover:rotate-0 transition-transform duration-500" />
                <img 
                  src="https://picsum.photos/seed/coding/800/600" 
                  alt="Coding Workspace" 
                  className="relative rounded-3xl shadow-xl w-full h-full object-cover -rotate-3 group-hover:rotate-0 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="section-padding">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Technical Arsenal</h2>
          <p className="text-ink/60 max-w-2xl mx-auto">
            The tools and technologies I'm mastering to build the next generation of intelligent applications.
          </p>
        </div>
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              whileHover={{ y: -5 }}
              className="p-6 bg-white rounded-2xl border border-primary/5 shadow-sm text-center hover:shadow-md transition-all"
            >
              <div className="w-12 h-12 bg-accent/10 text-accent rounded-xl flex items-center justify-center mx-auto mb-4">
                {skill.icon}
              </div>
              <h3 className="font-bold text-primary mb-1">{skill.name}</h3>
              <p className="text-xs font-semibold text-accent uppercase tracking-wider">{skill.level}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="section-padding bg-primary text-white overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 w-96 h-96 bg-accent rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-[120px]" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Projects</h2>
              <p className="text-white/60 max-w-xl">
                A showcase of my learning journey through practical application and experimentation.
              </p>
            </div>
            <a href="#" className="text-accent font-semibold flex items-center gap-2 hover:underline">
              View all on GitHub <ExternalLink className="w-4 h-4" />
            </a>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl overflow-hidden hover:bg-white/10 transition-all"
              >
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-8">
                  <div className="flex gap-2 mb-4">
                    {project.tags.map(tag => (
                      <span key={tag} className="text-[10px] font-bold uppercase tracking-widest px-2 py-1 bg-accent/20 text-accent rounded-md">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-xl font-bold mb-3">{project.title}</h3>
                  <p className="text-white/60 text-sm mb-6 line-clamp-2">
                    {project.description}
                  </p>
                  <a href={project.link} className="inline-flex items-center gap-2 text-sm font-bold text-accent hover:gap-3 transition-all">
                    Explore Project <ChevronRight className="w-4 h-4" />
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Resume Section */}
      <section id="resume" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Mohammad Sajid Bin Kamal</h2>
            <p className="text-ink/60">Curriculum Vitae • Computer Science & Engineering Student</p>
          </div>
          
          <div className="mb-16 grid md:grid-cols-3 gap-6">
            <div className="p-6 bg-surface rounded-2xl border border-primary/5">
              <h4 className="font-bold text-primary mb-2">Contact</h4>
              <p className="text-sm text-ink/60">01307284064</p>
              <p className="text-sm text-ink/60">mohammadsajid1114@gmail.com</p>
            </div>
            <div className="p-6 bg-surface rounded-2xl border border-primary/5">
              <h4 className="font-bold text-primary mb-2">Address</h4>
              <p className="text-sm text-ink/60">Jevco Palace, 9 No road, Hillview</p>
              <p className="text-sm text-ink/60">2no gate, Chattogram</p>
            </div>
            <div className="p-6 bg-surface rounded-2xl border border-primary/5">
              <h4 className="font-bold text-primary mb-2">Personal Info</h4>
              <p className="text-sm text-ink/60">DOB: 13/01/2003</p>
              <p className="text-sm text-ink/60">Religion: Islam</p>
            </div>
          </div>

          <div className="mb-16 p-8 bg-surface rounded-3xl border border-primary/5">
            <h4 className="font-bold text-primary mb-4">Career Objective</h4>
            <p className="text-ink/70 leading-relaxed">
              To obtain a position with opportunities to utilize my technical, branding and marketing experiences, skill, talent, creativity, sincerity for the better achievement of the organization.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Education */}
            <div className="space-y-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-accent/10 text-accent rounded-lg flex items-center justify-center">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-primary">Education</h3>
              </div>
              <div className="space-y-8 border-l-2 border-primary/5 pl-6">
                {resumeData.education.map((edu, index) => (
                  <div key={index} className="relative">
                    <div className="absolute -left-[31px] top-1.5 w-4 h-4 bg-white border-2 border-accent rounded-full" />
                    <span className="text-sm font-bold text-accent mb-1 block">{edu.period}</span>
                    <h4 className="text-lg font-bold text-primary">{edu.degree}</h4>
                    <p className="text-primary/70 font-medium">{edu.institute}</p>
                    <p className="text-ink/60 text-sm mt-1">
                      {edu.major} {edu.result ? `• Result: ${edu.result}` : edu.status ? `• ${edu.status}` : ''}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Experience */}
            <div className="space-y-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-accent/10 text-accent rounded-lg flex items-center justify-center">
                  <Layers className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-primary">Experience</h3>
              </div>
              <div className="space-y-8 border-l-2 border-primary/5 pl-6">
                {resumeData.experience.map((exp, index) => (
                  <div key={index} className="relative">
                    <div className="absolute -left-[31px] top-1.5 w-4 h-4 bg-white border-2 border-accent rounded-full" />
                    <h4 className="text-lg font-bold text-primary">{exp.role}</h4>
                    <p className="text-ink/60 text-sm mt-2 leading-relaxed">
                      {exp.description}
                    </p>
                  </div>
                ))}
              </div>

              {/* Technical Skills */}
              <div className="mt-12 pt-8 border-t border-primary/5">
                <h4 className="text-lg font-bold text-primary mb-4">Technical Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {resumeData.technicalSkills.map((skill, index) => (
                    <span key={index} className="px-4 py-2 bg-surface rounded-lg text-sm text-primary font-medium border border-primary/5">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Languages & Extra Skills */}
              <div className="mt-12 pt-8 border-t border-primary/5">
                <h4 className="text-lg font-bold text-primary mb-4">Languages</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {resumeData.languages.map((lang, index) => (
                    <div key={index} className="p-4 bg-surface rounded-xl">
                      <p className="font-bold text-primary text-sm">{lang.name}</p>
                      <p className="text-xs text-ink/60 mt-1">{lang.level}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center">
            <button 
              onClick={() => window.print()}
              className="px-8 py-3 border-2 border-primary text-primary rounded-xl font-bold hover:bg-primary hover:text-white transition-all"
            >
              Download Full CV
            </button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section-padding bg-surface">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">Get In Touch</h2>
              <p className="text-ink/70 text-lg mb-8">
                I'm always open to discussing new projects, creative ideas, or opportunities to be part of your visions.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-accent">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-primary">Email</h4>
                    <div className="flex items-center gap-2">
                      <p className="text-ink/60">mohammadsajid1114@gmail.com</p>
                      <button 
                        onClick={copyEmail}
                        className="p-1.5 hover:bg-surface rounded-md transition-colors text-ink/40 hover:text-accent"
                        title="Copy Email"
                      >
                        {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-accent">
                    <Linkedin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-primary">LinkedIn</h4>
                    <p className="text-ink/60">linkedin.com/in/mohammadsajid</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl shadow-primary/5 border border-primary/5">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-primary">Full Name</label>
                    <input 
                      type="text" 
                      placeholder="John Doe"
                      className="w-full px-4 py-3 bg-surface border border-primary/5 rounded-xl focus:outline-none focus:border-accent transition-colors"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-primary">Email Address</label>
                    <input 
                      type="email" 
                      placeholder="john@example.com"
                      className="w-full px-4 py-3 bg-surface border border-primary/5 rounded-xl focus:outline-none focus:border-accent transition-colors"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-primary">Subject</label>
                  <input 
                    type="text" 
                    placeholder="Project Inquiry"
                    className="w-full px-4 py-3 bg-surface border border-primary/5 rounded-xl focus:outline-none focus:border-accent transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-primary">Message</label>
                  <textarea 
                    rows={4}
                    placeholder="Tell me about your project..."
                    className="w-full px-4 py-3 bg-surface border border-primary/5 rounded-xl focus:outline-none focus:border-accent transition-colors resize-none"
                  />
                </div>
                <button className="w-full py-4 bg-primary text-white rounded-xl font-bold hover:bg-accent transition-all shadow-lg shadow-primary/20 flex items-center justify-center gap-2">
                  Send Message <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-primary/5 bg-white">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <a href="#home" className="text-2xl font-display font-bold text-primary tracking-tighter">
              MS<span className="text-accent">.</span>
            </a>
            <p className="text-ink/40 text-sm mt-2">© 2024 Mohammad Sajid. All rights reserved.</p>
          </div>
          
          <div className="flex items-center gap-6">
            <a href="#" className="text-primary/40 hover:text-accent transition-colors"><Github className="w-5 h-5" /></a>
            <a href="#" className="text-primary/40 hover:text-accent transition-colors"><Linkedin className="w-5 h-5" /></a>
            <a href="#" className="text-primary/40 hover:text-accent transition-colors"><Mail className="w-5 h-5" /></a>
          </div>

          <div className="flex gap-8">
            <a href="#about" className="text-sm font-medium text-primary/60 hover:text-accent transition-colors">About</a>
            <a href="#projects" className="text-sm font-medium text-primary/60 hover:text-accent transition-colors">Projects</a>
            <a href="#resume" className="text-sm font-medium text-primary/60 hover:text-accent transition-colors">Resume</a>
            <a href="#contact" className="text-sm font-medium text-primary/60 hover:text-accent transition-colors">Contact</a>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-8 right-8 w-12 h-12 bg-primary text-white rounded-full shadow-xl flex items-center justify-center hover:bg-accent transition-all z-40"
          >
            <ArrowUp className="w-6 h-6" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
